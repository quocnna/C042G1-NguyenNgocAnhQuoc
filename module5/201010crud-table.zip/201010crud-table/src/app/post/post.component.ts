import { EventListenerFocusTrapInertStrategy } from '@angular/cdk/a11y';
import { HttpClient } from '@angular/common/http';
import { AfterViewChecked, AfterViewInit, Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Post } from '../model/post';
import { PostService } from '../service/post.service';

export interface PeriodicElement {
  fname: string;
  lname: string;
  studentID: number;
  weight: number;
  symbol: string;
}

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  exampleDatabase: PostService | null;
  // abc: boolean = false;
  // listPost: Observable<Post[]>;
  listPost: Post[];
  test: Post[];
  onEditClick = (element) => this.onEdit(element);

  onEdit(element) {
    console.log(this.listPost);
  }

  constructor(private postServie: PostService){ 
    this.postServie.getPosts().subscribe(data => this.listPost = data);
    // this.listPost = this.postServie.getPosts();
    // tslint:disable-next-line: no-trailing-whitespace
    // this.listPost.subscribe(data => {this.test = data; console.log(this.test);});
    // console.log(this.test);

  }
  ngOnInit(): void {

    //   console.log("aaa");
    // this.postServie.getPosts().subscribe(
    //   data => this.listPost = data);

      //  console.log(this.listPost);
  }
    // this.postServie.getPosts().subscribe(
    //   data => this.listPost = data,
    //   err => console.log('aaa'),
    //   () => console.log(this.listPost)
    //   );
    // console.log(this.listPost); });

    // await this.postServie.getPosts().toPromise().then((data: Post[]) => this.listPost = data
    //   );


   // this.postService.getAsyncData().then(data => this.listPost = data);
//     this.postService
//     .getPosts().subscribe(next => { this.listPost = next; }, error => { console.log(error);

//       }, () => {
//       console.log(this.listPost); });

      // }, () => {
      // console.log(this.listPost); });
    // console.log(this.listPost);


  //ngOnInit(): void {
    // this.exampleDatabase = new PostService(this._httpClient);
    // this.exampleDatabase.getPosts().subscribe(next => { this.listPost = next; }, error => { console.log(error);

    // }, () => {
    // console.log(this.listPost); });
  //}

  // checkHeader(data) {
  //   if(data == 'id'){
  //     return 'ID';
  //   }else{
  //     return 'INVALID DATA';
  //   }
  // }

  columnHeader = {'id': 'ID', 'title': 'Title', 'edit': 'Edit'};

  // listPost= [
  //   {
  //     "id": 1,
  //     "title": "Post 4"
  //   },
  //   {
  //     "id": 2,
  //     "title": "Post 5"
  //   },
  //   {
  //     "id": 3,
  //     "title": "Post 6"
  //   }
  // ];
  
  // tableData: PeriodicElement[] = [
  //   {studentID: 1, fname: 'Hydrogen', lname: 'Nguyen', weight: 1.0079, symbol: 'H'},
  //   {studentID: 2, fname: 'Helium', lname: 'Le',weight: 4.0026, symbol: 'He'},
  //   {studentID: 3, fname: 'Lithium', lname: 'Tran',weight: 6.941, symbol: 'Li'},
  //   {studentID: 4, fname: 'Beryllium',lname: 'Doan', weight: 9.0122, symbol: 'Be'},
  //   {studentID: 5, fname: 'Boron', lname: 'Truong',weight: 10.811, symbol: 'B'},
  //   {studentID: 6, fname: 'Carbon', lname: 'Phong',weight: 12.0107, symbol: 'C'},
  //   {studentID: 7, fname: 'Nitrogen',lname: 'Dam', weight: 14.0067, symbol: 'N'},
  //   {studentID: 8, fname: 'Oxygen', lname: 'Banh',weight: 15.9994, symbol: 'O'},
  //   {studentID: 9, fname: 'Fluorine',lname: 'Ly', weight: 18.9984, symbol: 'F'},
  //   {studentID: 10, fname: 'Neon', lname: 'Phat',weight: 20.1797, symbol: 'Ne'},
  // ];
}
