
export class Post{
    id: number;
    title: string; }