import { AfterViewInit, Component, Inject, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject } from 'rxjs';
import { takeWhile } from 'rxjs/operators';
import { Post } from '../model/post';
import { PeriodicElement } from '../post/post.component';
import { PostService } from '../service/post.service';

@Component({
  selector: 'app-my-table',
  templateUrl: './my-table.component.html',
  styleUrls: ['./my-table.component.css']
})
export class MyTableComponent implements OnChanges, OnInit {
  constructor(public dialog: MatDialog, private postServie: PostService) { }
  // @Input() tableData;
  @Input() columnHeader;
  @Input() editButton;


  private _data = new BehaviorSubject<Post[]>([]);

  // change data to use getter and setter
  @Input()
  set tableData(value) {
      // set the latest value for _data BehaviorSubject
      this._data.next(value);
  }

  // tslint:disable-next-line: typedef
  get tableData() {
      // get the latest value from _data BehaviorSubject
      return this._data.getValue();
  }

  // tslint:disable-next-line: member-ordering
  objectKeys = Object.keys;
  // tslint:disable-next-line: member-ordering
  dataSource;

  @ViewChild(MatSort) sort: MatSort;

  // tslint:disable-next-line: typedef
  onEdit(element: any) {
    // this.dialog.open(DialogElementsExampleDialog);

    const dialogRef = this.dialog.open(DialogElementsExampleDialog, {
      width: '550px',
      data: element
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      element = result;
    });

    this.editButton(element);
  }
   ngOnChanges(changes: SimpleChanges): void {
  //   if (changes.tableData) {
  //     this.dataSource = new MatTableDataSource(this.tableData);
  //     // this.ngOnInit();
  // }
   }

  ngOnInit(): void {
    this._data.pipe(takeWhile(value => this.tableData == value))
            .subscribe(x => {
              this.dataSource = new MatTableDataSource(this.tableData);
            });
    // this.tableData.subscribe(data => {this.res = data; console.log(this.res);});
    // console.log(this.tableData);
    // this.dataSource = new MatTableDataSource(this.res);
    // this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}


@Component({
  selector: './dialog-elements-example-dialog',
  templateUrl: './dialog-elements-example-dialog.html',
})
// tslint:disable-next-line: component-class-suffix
export class DialogElementsExampleDialog implements OnInit {
  dataForm: PeriodicElement;
  constructor(
    public dialogRef: MatDialogRef<DialogElementsExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: PeriodicElement) {
      this.dataForm = data;
    }
  ngOnInit(): void {
    console.log(this.dataForm);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
