import { Component, OnInit } from '@angular/core';
import { CommentService } from '../service/comment.service';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
  columnHeader = {'id': 'ID', 'body': 'Body', 'postId': 'Post ID' , 'edit': 'Edit'};
  constructor(public commentService: CommentService) { }

  onEditClick() {

  }
  ngOnInit(): void {
  }

}
