import { AfterViewInit, Component, Inject, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject } from 'rxjs';
import { takeWhile } from 'rxjs/operators';
import { CommentTestModal } from '../comment/comment.component';
import { CommentDTO } from '../model/commentdto';
import { Post } from '../model/post';
import { PostService } from '../service/post.service';

@Component({
  selector: 'app-my-table',
  templateUrl: './my-table.component.html',
  styleUrls: ['./my-table.component.css']
})
export class MyTableComponent implements OnChanges, OnInit {
  constructor(public dialog: MatDialog, private modalService: NgbModal) { }
  // @Input() tableData;
  @Input() columnHeader;
  @Input() editButton;

  @Input() testService;
  cmtDTO: CommentDTO;
  listDTO: CommentDTO[] = [];
  private _data = new BehaviorSubject<any[]>([]);

  // change data to use getter and setter
  @Input()
  set tableData(value) {
      // set the latest value for _data BehaviorSubject
      this._data.next(value);
  }

  // tslint:disable-next-line: typedef
  get tableData() {
      // get the latest value from _data BehaviorSubject
      return this._data.getValue();
  }

  // tslint:disable-next-line: member-ordering
  objectKeys = Object.keys;
  // tslint:disable-next-line: member-ordering
  dataSource;

  @ViewChild(MatSort) sort: MatSort;

  // tslint:disable-next-line: typedef
  onEdit(element) {
    
    // this.dialog.open(DialogElementsExampleDialog);

    // const dialogRef = this.dialog.open(DialogElementsExampleDialog, {
    //   width: '550px',
    //   data: element
    // });
    // dialogRef.componentInstance.myService = this.testService; 

    // dialogRef.afterClosed().subscribe(result => {
      
    //   // element = result;
    //   // console.log(element);
    // });
    this.editButton(element, this.modalService);
    // const modalRef = this.modalService.open(CommentTestModal);
    // modalRef.componentInstance.name = 'World';
   
  }

  onDelete(element){
    this.testService.delete(element.id).subscribe();
    this.ngOnInit();
  }

   ngOnChanges(changes: SimpleChanges): void {
  //    console.log('aaaaa');
  //   if (changes.listDTO) {
  //   //   console.log(this.dataSource);
  //     this.dataSource = new MatTableDataSource(this.listDTO);
  // //     // this.ngOnInit();
  // }
      
   }

  ngOnInit(): void {
    // this._data.pipe(takeWhile(value => this.tableData == value))
    //         .subscribe(x => {
    //           this.dataSource = new MatTableDataSource(this.tableData);
    //         });


            this.testService.getAll().subscribe(data => {
                this.listDTO= [];


                for(let i=0; i< Object.values(data).length; i++){
                  // tslint:disable-next-line: no-unused-expression
                  // CommentDTO cmd = new CommentDTO(1,'a',3,'d');
                  this.cmtDTO = new CommentDTO();
                  this.cmtDTO.id= data[i].id;
                  this.cmtDTO.body= data[i].body;
                  this.cmtDTO.postId= data[i].postId;
                  this.cmtDTO.postTitle= data[i].post.title;  
                  this.listDTO.push(this.cmtDTO);
                };
                
              this.dataSource = new MatTableDataSource(this.listDTO);  
                


                                                        
                                                          
                                                          
                                                          });
    // this.tableData.subscribe(data => {this.res = data; console.log(this.res);});
    
  
    // this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}


@Component({
  selector: './dialog-elements-example-dialog',
  styles: ['.example-container .mat-form-field + .mat-form-field { margin-left: 8px;}'],
  templateUrl: './dialog-elements-example-dialog.html',
})
// tslint:disable-next-line: component-class-suffix
export class DialogElementsExampleDialog implements OnInit {
  @Input() myService;
  dataForm;
  constructor(
    public dialogRef: MatDialogRef<DialogElementsExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data) {
      this.dataForm = data;
    }
  ngOnInit(): void {
    // console.log(this.dataForm);
    // this.myService.deletePost(this.dataForm.id).subscribe();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
