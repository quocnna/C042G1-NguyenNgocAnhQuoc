import { EventListenerFocusTrapInertStrategy } from '@angular/cdk/a11y';
import { HttpClient } from '@angular/common/http';
import { AfterViewChecked, AfterViewInit, Component, Inject, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { Post } from '../model/post';
import { PostService } from '../service/post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  //exampleDatabase: PostService | null;
  // abc: boolean = false;
  // listPost: Observable<Post[]>;
  // listPost: Post[];
  columnHeader = {'id': 'ID', 'title': 'Title', 'action': 'Action'};
  //test: Post[];
  //onEditClick = (element) => this.onEdit(element);

  onEditClick(element) {
    const dialogRef = this.dialog.open(DialogTest, {
      width: '550px',
      data: element
    });
  }

  constructor(public postServie: PostService, public dialog: MatDialog){ 
    // this.postServie.getPosts().subscribe(data => this.listPost = data);
    // this.listPost = this.postServie.getPosts();
    // tslint:disable-next-line: no-trailing-whitespace
    // this.listPost.subscribe(data => {this.test = data; console.log(this.test);});
    // console.log(this.test);

  }
  ngOnInit(): void {
    // this.postServie.getPosts().subscribe(
    //   data => this.listPost = data);

      //  console.log(this.listPost);
  }
    // this.postServie.getPosts().subscribe(
    //   data => this.listPost = data,
    //   err => console.log('aaa'),
    //   () => console.log(this.listPost)
    //   );
    // console.log(this.listPost); });

    // await this.postServie.getPosts().toPromise().then((data: Post[]) => this.listPost = data
    //   );


   // this.postService.getAsyncData().then(data => this.listPost = data);
//     this.postService
//     .getPosts().subscribe(next => { this.listPost = next; }, error => { console.log(error);

//       }, () => {
//       console.log(this.listPost); });

      // }, () => {
      // console.log(this.listPost); });
    // console.log(this.listPost);


  //ngOnInit(): void {
    // this.exampleDatabase = new PostService(this._httpClient);
    // this.exampleDatabase.getPosts().subscribe(next => { this.listPost = next; }, error => { console.log(error);

    // }, () => {
    // console.log(this.listPost); });
  //}

  // checkHeader(data) {
  //   if(data == 'id'){
  //     return 'ID';
  //   }else{
  //     return 'INVALID DATA';
  //   }
  // }
}


@Component({
  selector: './dialog-test',
  templateUrl: './dialog-test.html',
})
// tslint:disable-next-line: component-class-suffix
export class DialogTest implements OnInit {
  postForm: FormGroup;
  dataForm;
  constructor(
    public dialogRef: MatDialogRef<DialogTest>,
    @Inject(MAT_DIALOG_DATA) public data, private postService: PostService, private fb: FormBuilder) {console.log(data);
      //  this.dataForm = data;
    }
  ngOnInit(): void {
    // console.log(this.data.title);
    this.postForm = this.fb.group({
      id: this.data.id,
      title: this.data.title,
      author: this.data.author
    });
    // this.myService.deletePost(this.dataForm.id).subscribe();
  }

  onNoClick(): void {
    console.log(this.postForm.value);
    this.dialogRef.close();
  }

  onSubmit(){
    console.log(this.postForm.value);
  }
}