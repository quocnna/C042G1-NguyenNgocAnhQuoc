import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Post } from '../model/post';
import { CommentService } from '../service/comment.service';
import { PostService } from '../service/post.service';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
  columnHeader = {'id': 'ID', 'body': 'Body', 'postTitle': 'Post Title' , 'action': 'Action'};
  constructor(public commentService: CommentService) { }

  onEditClick(element, modal) {
    const modalRef = modal.open(CommentTestModal);
    modalRef.componentInstance.data = element ?? new Comment();
    modalRef.componentInstance.title = element ?  "edit" : "add";

  }

  ngOnInit(): void {
  }

}



@Component({
  templateUrl: './comment-modal.html'
})
export class CommentTestModal implements OnInit {
  @Input() title;
  @Input() data;
  commentForm: FormGroup;
  listPost: Post[] = [];

  // @Input() dataForm;
  constructor(public activeModal: NgbActiveModal, private postService: PostService, private commentService: CommentService, private fb: FormBuilder, private router: Router) {
    postService.getAll().subscribe(da => this.listPost= da);
  }
  ngOnInit(): void {
    this.commentForm = this.fb.group({
      id: this.data.id,
      body: [this.data.body, [Validators.required, Validators.email, gmailValidator]],
      postId: this.data.postId
    });
  }
  get commentFormControl() {
    return this.commentForm.controls;
  }

  

  onSubmit(){
    if(this.commentForm.value.id)
    this.commentService.update(this.commentForm.value.id, this.commentForm.value).subscribe();
    else
      this.commentService.create(this.commentForm.value).subscribe();

      this.router.navigateByUrl('/');
  //     this.router.navigate(['/comment'])
  // .then(() => {
  //   window.location.reload();

  // });
    this.activeModal.close();
    // this.router.navigate(['/', '']);
  }
}

// export const yearValidation = (control: FormGroup): { [key: string]: boolean } | null => {
//   const year = control.get('year');
//   return year.match(/\D.*/) ? { isError: true } : null;
// }

function gmailValidator(formControl: FormControl){

  if(formControl.value){
 if(formControl.value.includes('@gmail.com')){
    return null;
  }
  }
    return { gmail: true};
}
  
