import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centered-content-layout',
  templateUrl: './centered-content-layout.component.html',
  styleUrls: ['./centered-content-layout.component.css'],
})
export class CenteredContentLayoutComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
