import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Post } from '../model/post';
import {map} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class PostService {
  private readonly API_URL = 'http://localhost:3000/posts/';
  listPost: Post[] = [];
  constructor(private http: HttpClient) { }

  getAll(): Observable<Post[]> {
    return this.http.get<Post[]>(this.API_URL);
    // return this.http.get<Post[]>(this.API_URL).pipe(map(data => data.filter((post, i) => i < count)) );
    }

    delete(id: number): Observable<void>{
      return this.http.delete<void>(this.API_URL + id);
    }

    update(post: Post,id: number): Observable<void>{
      return this.http.put<void>(this.API_URL + id, post);
    }
    // tslint:disable-next-line: typedef
    // async getAsyncData(): Promise<Post[]> {
    //   return await this.http.get<Post[]>(this.API_URL).toPromise().then(res => JSON.parse(JSON.stringify(res)).data)
    //   .then(res => {
    //     console.log(res);
    //     // you returned no value here!
    //     return res;
    //   });
      // console.log('No issues, I will wait until promise is resolved..');
    // }

}
