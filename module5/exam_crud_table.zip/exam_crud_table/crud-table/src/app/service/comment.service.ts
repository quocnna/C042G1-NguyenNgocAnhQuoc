import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommentService {
  private readonly API_URL = 'http://localhost:3000/comments';
  // listComment: Comment[];
  constructor(private http: HttpClient) { }

  getAll(): Observable<Comment[]>{
    return this.http.get<Comment[]>(this.API_URL + '?_expand=post');
  }

  create(cm: Comment): Observable<void>{
    return this.http.post<void>(this.API_URL, cm);
  }

  update(id: number, cm: Comment): Observable<void>{
    return this.http.put<void>(this.API_URL + '/' + id, cm);
  }

  delete(id: number): Observable<void>{
    return this.http.delete<void>(this.API_URL + '/' + id);
  }
}
