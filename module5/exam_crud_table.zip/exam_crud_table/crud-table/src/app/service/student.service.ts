import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from '../model/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private readonly API_URL = 'http://localhost:3000/students';

  constructor(private http: HttpClient) { }

  getAll(): Observable<Student[]>{
    return this.http.get<Student[]>(this.API_URL);
  }

  create(cm: Student): Observable<void>{
    return this.http.post<void>(this.API_URL, cm);
  }

  update(id: number, cm: Student): Observable<void>{
    return this.http.put<void>(this.API_URL + '/' + id, cm);
  }

  delete(id: number): Observable<void>{
    return this.http.delete<void>(this.API_URL + '/' + id);
  }

}
