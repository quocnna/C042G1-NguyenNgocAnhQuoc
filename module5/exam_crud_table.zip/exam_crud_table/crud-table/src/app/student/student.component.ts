import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { StudentService } from '../service/student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent {
  columnHeader = {'id': 'ID', 'ten_sinh_vien': 'Student Name', 'ten_nhom': 'Group Name', 'ten_de_tai': 'Project Name', 'giao_vien_huong_dan': 'Teacher Name', 'email': 'Email', 'so_dien_thoai': 'Phone Number', 'action': 'Action'};
  constructor(public studentService: StudentService) { }

  onEditClick(element, modal) {
    const modalRef = modal.open(StudentModal);
    modalRef.componentInstance.data = element;
  }
}

@Component({
  templateUrl: './student-modal.html'
})
export class StudentModal implements OnInit {
  @Input() data;
  studentForm: FormGroup;

  constructor(public activeModal: NgbActiveModal, private studentService: StudentService, private fb: FormBuilder, private router: Router) {
  }
  ngOnInit(): void {
    this.studentForm = this.fb.group({
      id: this.data.id,
      ten_sinh_vien: [this.data.ten_sinh_vien, [Validators.required]],
      ten_nhom: [this.data.ten_nhom, [Validators.required, validGroup]],
      ten_de_tai: [this.data.ten_de_tai, [Validators.required]],
      giao_vien_huong_dan: [this.data.giao_vien_huong_dan, [Validators.required]],
      email: [this.data.email, [Validators.required, defValidator]],
      so_dien_thoai: [this.data.so_dien_thoai, [Validators.required, Validators.minLength(10), Validators.minLength(12)]]
    });
  }  

  onSubmit(){
    this.studentService.update(this.studentForm.value.id, this.studentForm.value).subscribe();

      this.router.navigate(['/'])
  .then(() => {
    window.location.reload();
  });
  
  }
}

//#region valid fc
function defValidator(formControl: FormControl){
 if(formControl.value.includes('@def.com'))
    return null;
    return { defMail: true};
}

function validGroup(formControl: FormControl){
  if(formControl.value.includes('Nhom 1') || formControl.value.includes('Nhom 2') || formControl.value.includes('Nhom 3'))
  return null;
  return { groupName: true};
}
//#endregion