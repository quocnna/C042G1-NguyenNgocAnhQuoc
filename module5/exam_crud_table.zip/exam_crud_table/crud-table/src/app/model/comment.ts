export class Comment{
    id: number;
    body: string;
    postId: number; }