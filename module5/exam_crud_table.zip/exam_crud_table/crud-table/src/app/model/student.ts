export class Student{
    id: number;
    ten_sinh_vien: string;
    ten_nhom: string;
    ten_de_tai: string;
    giao_vien_huong_dan: string;
    email: string;
    so_dien_thoai: string;
 }