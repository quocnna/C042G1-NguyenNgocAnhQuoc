export class CommentDTO{
    id: number;
    body: string;
    postId: number;
    postTitle: string;

    // constructor(id: number, body: string, postId: number, postTitle: string){
    //     this.id= id;
    //     this.body= body;
    //     this.postId= postId;
    //     this.postTitle= postTitle;
    // };
}