import { Route } from '@angular/compiler/src/core';
import { AfterViewInit, Component, Inject, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject } from 'rxjs';
import { takeWhile } from 'rxjs/operators';
import { CommentTestModal } from '../comment/comment.component';
import { CommentDTO } from '../model/commentdto';
import { Post } from '../model/post';
import { PostService } from '../service/post.service';

@Component({
  selector: 'app-my-table',
  templateUrl: './my-table.component.html',
  styleUrls: ['./my-table.component.css']
})
export class MyTableComponent implements OnInit {
  constructor(public dialog: MatDialog, private modalService: NgbModal) { }
  // @Input() tableData;
  @Input() columnHeader;
  @Input() editButton;

  @Input() testService;
  cmtDTO: CommentDTO;
  listDTO: CommentDTO[] = [];
  private _data = new BehaviorSubject<any[]>([]);

  @Input()
  set tableData(value) {
      this._data.next(value);
  }

  // tslint:disable-next-line: typedef
  get tableData() {
      return this._data.getValue();
  }


  objectKeys = Object.keys;

  dataSource;

  @ViewChild(MatSort) sort: MatSort;

  onEdit(element) {
    this.editButton(element, this.modalService);
  }

  onDelete(element){
    const modalRef = this.modalService.open(DeleteModal);
    modalRef.componentInstance.id = element.id;
    modalRef.componentInstance.service = this.testService;
  }

  ngOnInit(): void {

            // this.testService.getAll().subscribe(data => {
            //     this.listDTO= [];
            //     for(let i=0; i< Object.values(data).length; i++){
            //       // tslint:disable-next-line: no-unused-expression
            //       // CommentDTO cmd = new CommentDTO(1,'a',3,'d');
            //       this.cmtDTO = new CommentDTO();
            //       this.cmtDTO.id= data[i].id;
            //       this.cmtDTO.body= data[i].body;
            //       this.cmtDTO.postId= data[i].postId;
            //       this.cmtDTO.postTitle= data[i].post.title;  
            //       this.listDTO.push(this.cmtDTO);
            //     };
                
            //   this.dataSource = new MatTableDataSource(this.listDTO);});


            this.testService.getAll().subscribe(data => {
              this.dataSource = new MatTableDataSource(data);});

    // this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}

@Component({
  templateUrl: './delete-modal.html'
})
export class DeleteModal{
  @Input() service;
  @Input() id;
  constructor(public activeModal: NgbActiveModal, private router: Router) {}

  delete(){
      this.service.delete(this.id).subscribe();

    this.router.navigate(['/'])
  .then(() => {
    window.location.reload();
  });
  }
}
