import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Student } from '../model/student';

@Component({
  selector: 'app-student-detail',
  templateUrl: './student-detail.component.html',
  styleUrls: ['./student-detail.component.css']
})
export class StudentDetailComponent {
  @Input() childMessage: string;
  @Input() student = new Student();

  @Output() finish = new EventEmitter<Student>();

  constructor() { }

  testOutput(){
     this.finish.emit(new Student("a","b","c")); 
  }

}
