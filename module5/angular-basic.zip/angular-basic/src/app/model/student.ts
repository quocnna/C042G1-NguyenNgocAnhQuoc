export class Student{
    name:string;
    email:string;
    phone:string;
    mark?:number;

    // constructor(){};
    constructor(name?:string,email?:string,phone?:string){
        this.name= name;
        this.email= email;
        this.phone= phone;
    };
}