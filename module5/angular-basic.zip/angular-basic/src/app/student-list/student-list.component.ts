import { Component, OnInit } from '@angular/core';
import { Student } from '../model/student';

// interface IStudent{
//   name:string,
//   email:string,
//   phone:string,
//   mark?:number
// }

const Students:Student[]=[
  {
    name:"Quoc",
    email:"quocnna@gmail.com",
    phone:"0708230984",
    mark:9
  },
  {
    name:"Dung",
    email:"dungnna@gmail.com",
    phone:"0708230985"
  },
  {
    name:"Toan",
    email:"toannna@gmail.com",
    phone:"0708230991"
  },
];

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent {

  parentMessage: string;
  student = new Student();
  students= Students;

  constructor() { }

  viewDetail(val:Student){
    this.student= val;
    this.parentMessage="test ms";
    console.log(this.student.name);
  }

  myMt(val:Student){
    console.log(val);
  }
  // ngOnInit(): void {
  // }

}
